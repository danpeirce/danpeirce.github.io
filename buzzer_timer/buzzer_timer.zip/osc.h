void set_osc_32MHz(void);
