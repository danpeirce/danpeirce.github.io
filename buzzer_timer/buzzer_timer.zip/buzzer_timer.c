#include "config_bits.h"  // device specific configuration
#include "pins.h"
#include "osc.h"
#include <timers.h>

void open_timer(void);
void open_compare(void);
void buzzer_task(void);

enum state_type { Reset, TenSec, FiveSec, Buzz };
enum state_type state;

void main(void)
{
    set_osc_32MHz();   // sets osc speed to 32 MHz

    speaker_Dir = OUTPUT;  //** Set as an input until buzzer is to sound
    ten_sec_Dir = INPUT;  // switch
    five_sec_Dir = INPUT; // switch
    reset_Dir = INPUT;    // switch
    buzz_now = INPUT;     // switch
    
    open_timer();
    open_compare();

    state = Buzz;

    while(1)
    {
        if ( state && PIR2bits.CCP2IF  ) 
        {
            buzzer_task();
        }
    }
}


void open_timer(void)
{
    OpenTimer1( TIMER_INT_OFF & T1_16BIT_RW &
                T1_SOURCE_INT & T1_PS_1_8   &
                T1_OSC1EN_OFF & T1_SYNC_EXT_OFF &
                T1_SOURCE_CCP );
}

void open_compare(void)
{
    RCONbits.IPEN = 1;    // set to known state although hardware interups not used here
    INTCONbits.GIEH = 0;  // disable all interupts
    INTCONbits.GIEL = 0;
    PIE1bits.CCP1IE = 0;  // disable ccp1 interupt
    PIE2bits.CCP2IE = 0;  // disable ccp2 interupt
    
    CCP1CON = 0x0A; // use CPP1IF interupt flag not pin
    CCP2CON = 0x0A; // use CPP2IF interupt flag not pin
    CCPR2H = 0;
    CCPR2L = 0;
    PIR2bits.CCP2IF = 0;
    
}

void buzzer_task(void)
{
    enum SEQUENCE_ENUM { stepOne, stepTwo, stepThree, stepFour};

    struct sixteenbit_struct {
        unsigned  lower:8;
        unsigned  upper:8;
    };
    union sixteenbit_parts {
        struct sixteenbit_struct byte;
        unsigned int whole_int;
    };       
    static union sixteenbit_parts compare_register = 0;
    static enum SEQUENCE_ENUM wave_seq = stepOne;
    static unsigned int duration[] = {270,350,350,2250};

    compare_register.whole_int = compare_register.whole_int + duration[wave_seq];
    CCPR2H = compare_register.byte.upper;
    CCPR2L = compare_register.byte.lower;
    
    PIR2bits.CCP2IF = 0;
    if ( (wave_seq == stepOne) || (wave_seq == stepThree) ) speaker = HIGH;
    else speaker = LOW;
    if (wave_seq == stepFour) wave_seq = stepOne;
    else wave_seq++;

}