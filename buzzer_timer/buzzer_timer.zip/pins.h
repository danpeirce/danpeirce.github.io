#include <p18f4525.h>

// PORTDbits.RD0 is declared in p18f4525.h
#define PIN19   PORTDbits.RD0
#define PIN20   PORTDbits.RD1
#define PIN21   PORTDbits.RD2
#define PIN22   PORTDbits.RD3
#define PIN27   PORTDbits.RD4
#define PIN28   PORTDbits.RD5
#define PIN29   PORTDbits.RD6
#define PIN30   PORTDbits.RD7
  
// TRISDbits.TRISD0 is declared in p18f4525.h
#define PIN19_Dir   TRISDbits.TRISD0
#define PIN20_Dir   TRISDbits.TRISD1
#define PIN21_Dir   TRISDbits.TRISD2
#define PIN22_Dir   TRISDbits.TRISD3
#define PIN27_Dir   TRISDbits.TRISD4
#define PIN28_Dir   TRISDbits.TRISD5
#define PIN29_Dir   TRISDbits.TRISD6
#define PIN30_Dir   TRISDbits.TRISD7

#define OUTPUT 0
#define INPUT  1
#define HIGH   1
#define LOW    0

//**************************************
// Project Specific pin Definitions

#define speaker_Dir     PIN20_Dir
#define ten_sec_Dir     PIN21_Dir
#define five_sec_Dir    PIN22_Dir
#define reset_Dir       PIN27_Dir
#define buzz_now_Dir    PIN28_Dir

#define speaker     PIN20
#define ten_sec     PIN21
#define five_sec    PIN22
#define reset       PIN27
#define buzz_now    PIN28

//*************************************
