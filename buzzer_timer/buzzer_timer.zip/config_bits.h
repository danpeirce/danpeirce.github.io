//  file config_bits.h
//  by Dan Peirce B.Sc.
//  Kwantlen University College
//  *********************
//  target PIC18F4525
//  MPLAB C18 compiler
//  *********************
//  April 13, 2007
//  version 1
//*****************************************************************
// The following are compiler directives that set some options
// of the PIC18F4525

#pragma config WDT = OFF
#pragma config OSC = INTIO7  // puts osc/4 on pin 14 to check freq
#pragma config MCLRE = OFF
#pragma config LVP = OFF
//******************************************************************

#include <p18f4525.h>


