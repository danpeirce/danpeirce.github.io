#include <p18F4525.h>
#include "osc.h"

//*****************************************************************
// sets osc to 32 MHz
//*****************************************************************
void set_osc_32MHz(void)
{
	int i; 
   	OSCCONbits.IRCF2 = 1;     // Set the OSCILLATOR Control Register to 8 MHz
   	OSCCONbits.IRCF1 = 1;      
 	OSCCONbits.IRCF0 = 1;      
  	OSCTUNEbits.PLLEN = 1;    // Enable PLL, boosts speed by 4x to 32 MHz
  	for(i=0;i<500;i++);       // delay to allow clock PLL to lock (stabilize)
}       
//*****************************************************************
