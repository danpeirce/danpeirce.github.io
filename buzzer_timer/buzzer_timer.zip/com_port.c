//  file com_port.c
//  by Dan Peirce B.Sc.
//  Kwantlen University College

//  *********************
//  target PIC18F4525
//  MPLAB C18 compiler
//  *********************

//  April 13, 2007
//  version 1

#include <p18f4525.h>
#include <usart.h>
#include <stdio.h>
#include <delays.h>
#include "com_port.h"


//*****************************************************************
// sets osc to 32 MHz
//*****************************************************************
void set_osc_32MHz(void)
{
	int i; 
   	OSCCONbits.IRCF2 = 1;     // Set the OSCILLATOR Control Register to 8 MHz
   	OSCCONbits.IRCF1 = 1;      
 	OSCCONbits.IRCF0 = 1;      
  	OSCTUNEbits.PLLEN = 1;    // Enable PLL, boosts speed by 4x to 32 MHz
  	for(i=0;i<500;i++);       // delay to allow clock PLL to lock (stabilize)
}       
//*****************************************************************


//*****************************************************************
//           openPORTCforUSART()
//*****************************************************************
void openPORTCforUSART(void);
//*****************************************************************


//*********************************************************************************************
//                          OpenCom()
//*********************************************************************************************
void OpenCom(void)
{
    openPORTCforUSART();
    OpenUSART( USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & 
                 USART_CONT_RX & USART_BRGH_HIGH, 103 );            // for 19200 bit per second
                               // (32000000/19200/16)-1 = 103.17
                  // actual buad rate is 32000000/(16*(103+1)) = 19230.8 baud
}
//*********************************************************************************************


//****************************************************************
//                          openPORTCforUSART()
//****************************************************************
void openPORTCforUSART(void)
{
  TRISCbits.TRISC6 = 0;  // set TX (RC6) as output 
  TRISCbits.TRISC7 = 1;  // and RX (RC7) as input
}
//****************************************************************

//****************************************************************

//****************************************************************
//        WaitForSplashScreen()
//****************************************************************
void WaitForSplashScreen(void)
{
    Delay10KTCYx(0);
    Delay10KTCYx(0);
    Delay10KTCYx(0);
    Delay10KTCYx(0);
    Delay10KTCYx(0);
    Delay10KTCYx(0);
}

//****************************************************************

//****************************************************************
//               CLS()          
//****************************************************************
void CLS(void)  // for clear screen
{
   printf("%c%c",0xFE,0x01); //Command - clear and zero serial
                             //  LCD   display
}

//****************************************************************


//****************************************************************
//               Move_Cursor          
//****************************************************************
// valid row is 0 or 1
// valid column is 0 to 15

void Move_Cursor( unsigned char row_num , unsigned char column_num )
{
 if (column_num > 15u ) column_num = 15u;
 if (row_num >= 1u ) row_num = 0x40;
 else row_num = 0u;
 printf("%c%c",0xFE,(0x80 + row_num + column_num) ); 
                     //Command - move to Line 1 - 13th position
                     //  of LCD display
}
//****************************************************************
