//  file com_port.h
//  by Dan Peirce B.Sc.
//  Kwantlen University College

//  *********************
//  target PIC18F4525
//  MPLAB C18 compiler
//  *********************

//  April 13, 2007
//  version 1

// OpenCom must be called before attempting to use
// a printf() function call
// NOTE:
// PIN 25 -- RC6 -- is used as TX (set as an output)
// PIN 26 -- RC7 -- is used as RX (set as an input)

void OpenCom(void); // defined in com_port.c
void set_osc_32MHz(void); 

void CLS(void);  // for clear screen
void Move_Cursor( unsigned char row_num , unsigned char column_num );
void WaitForSplashScreen(void);
