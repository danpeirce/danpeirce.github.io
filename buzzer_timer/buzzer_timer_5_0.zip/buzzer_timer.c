#include "config_bits.h"  // device specific configuration
#include "pins.h"
#include "osc.h"
#include <timers.h>

struct sixteenbit_struct {          // this sets up a bitfield structure
    unsigned  lower:8;
    unsigned  upper:8;
};
union sixteenbit_parts {             // The union allows one to refer to the 
    struct sixteenbit_struct byte;   // same address space with different names.
    unsigned int whole_int;          // In this case one can make expressions with
};                                   // ether the whole_int (16 bits) or either byte
                                     // of the int (upper or lower 8 bits)
union sixteenbit_parts next_compare1;

void open_timer(void);
void open_compare(void);
void buzzer_task(void);
void read_process_switches(void);
void setup_state(void);
void time_is_up(void);
void ten_msec_task(void);
void reset_times(void);

enum state_type { Reset, TenSec, FiveSec, Buzz };
enum state_type state=Reset;

unsigned int time, ten_msec_count=0, sec_count=0;
const unsigned int ten_msec_duration = 10000u;
void main(void)
{

    set_osc_32MHz();   // sets osc speed to 32 MHz

    SPEAKER_DIR = INPUT;  // Set as an input until buzzer is to sound
    TEN_SEC_DIR = INPUT;  // refers to input pin
    FIVE_SEC_DIR = INPUT; // refers to input pin
    RESET_DIR = INPUT;    // refers to input pin
    BUZZ_NOW = INPUT;     // refers to input pin
    
    open_timer();
    open_compare();


    while(1)
    {
        read_process_switches(); 

        if ( (state == TenSec) && (sec_count == 10u)) time_is_up();
        else if ( (state == FiveSec) && (sec_count == 5u) ) time_is_up();
        if ( PIR2bits.CCP2IF  ) buzzer_task();
        if (PIR1bits.CCP1IF) ten_msec_task();
    }
}

void ten_msec_task(void)
{

    next_compare1.whole_int = next_compare1.whole_int + ten_msec_duration;
    CCPR1H = next_compare1.byte.upper;
    CCPR1L = next_compare1.byte.lower;
    PIR1bits.CCP1IF = 0;
    ten_msec_count++;
    if (ten_msec_count >= 100u)
    {
        ten_msec_count = 0;
        sec_count++;
    }
}

void time_is_up(void)
{
    state = Buzz;            // timer over so jump to Buzz state
    SPEAKER_DIR = OUTPUT;    // enable buzzer output
    PIR1bits.CCP1IF = 0;     // reset timer1 interupt flag
}

void read_process_switches(void)
{
    static enum state_type old_state=0;

    old_state = state;
                                //in order of priority
    if (RESET)  state = Reset;  // checks RESET switch INPUT
    else if (FIVE_SEC) state = FiveSec; // checks FIVE_SEC switch input
    else if (TEN_SEC) state = TenSec;   // checks TEN_SEC switch input
    else if (BUZZ_NOW) state = Buzz;    // checks BUZZ_NOW switch input
    if (state != old_state) 
    {
        time = ReadTimer1();   // read timer if there is a change in state
        setup_state();
    }
}

void setup_state()
{
   
    switch (state) 
    {
        case Buzz:
            SPEAKER_DIR = OUTPUT;  // set control pin as an output
            break;
        case Reset:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            break;
        case TenSec:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            reset_times();
            break;
        case FiveSec:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            reset_times();
            break;
    }
}

void reset_times(void)
{
            next_compare1.whole_int = time + ten_msec_duration;
            CCPR1H = next_compare1.byte.upper;
            CCPR1L = next_compare1.byte.lower;
            PIR1bits.CCP1IF = 0;
            ten_msec_count = 0;
            sec_count = 0;
}

void open_timer(void)
{
//    OpenTimer0( TIMER_INT_OFF & T0_16BIT & T0_SOURCE_EXT & T0_EDGE_FALL & T0_PS_1_256 );

    OpenTimer1( TIMER_INT_OFF & T1_16BIT_RW &
                T1_SOURCE_INT & T1_PS_1_8   &
                T1_OSC1EN_OFF & T1_SYNC_EXT_OFF &
                T1_SOURCE_CCP );
}

void open_compare(void)
{
    const unsigned char compare_mode_code = 0B00001010; // code from PIC18F4525 databook
                                                      // page 139 for CCPxCON register

    RCONbits.IPEN = 1;    // set to known state although hardware interups not used here
    INTCONbits.GIEH = 0;  // disable all interupts
    INTCONbits.GIEL = 0;
    PIE1bits.CCP1IE = 0;  // disable ccp1 interupt
    PIE2bits.CCP2IE = 0;  // disable ccp2 interupt
    
    CCP1CON = compare_mode_code; // use CPP1IF interupt flag and not the CCP1 pin
    CCP2CON = compare_mode_code; // use CPP2IF interupt flag and not the CCP2 pin
    CCPR2H = 0;
    CCPR2L = 0;
    next_compare1.whole_int = ReadTimer1() + ten_msec_duration;
    CCPR1H = next_compare1.byte.upper;
    CCPR1L = next_compare1.byte.lower;
    PIR1bits.CCP1IF = 0;
    PIR2bits.CCP2IF = 0;
    PIR1bits.CCP1IF = 0;
}

void buzzer_task(void)
{
    enum SEQUENCE_ENUM { stepOne, stepTwo, stepThree, stepFour};

 
    static union sixteenbit_parts compare2_register = 0;
    // the variable compare_register contains the value that the compare register was last set to
    // then the value it will next be set to.

    static enum SEQUENCE_ENUM wave_seq = stepOne;
    static unsigned int duration[] = {270,350,350,2250};

    compare2_register.whole_int = compare2_register.whole_int + duration[wave_seq];
    CCPR2H = compare2_register.byte.upper;
    CCPR2L = compare2_register.byte.lower;
    
    PIR2bits.CCP2IF = 0;
    if ( (wave_seq == stepOne) || (wave_seq == stepThree) ) SPEAKER = HIGH;
    else SPEAKER = LOW;
    if (wave_seq == stepFour) wave_seq = stepOne;
    else wave_seq++;

}