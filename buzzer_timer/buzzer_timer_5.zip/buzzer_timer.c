/* ***********************************************
File buzzer_timer.c
project written by Dan Peirce B.Sc.
at Kwantlen University College for
the Kwantlen Science Challenge.

last rev. Nov.22 2007  comments added
***********************************************   */

/* 
*************************************************
This prgram will do the following
   1. The 9 Vdc 800 mA AC wall adapter plugs into the 9 Vdc power jack 
      at the back of the speaker unit. The other jacks on the back of the 
      unit are no longer used.
   2. The power switch, power LED and volume control operate as before.
   3. Four momentary switches have been added to the top of the case. They 
      are labeled as:
      Buzz Now, Reset, ten sec. and five sec.
   4. The buzzer has 4 modes corresponding to the four switches. Pressing a 
      switch will cancel the previous mode and activate the new mode unless 
      the buzzer timer is already in that mode. If a switch is pressed that 
      corresponds to the current mode nothing will change. The two time modes 
      are time limited. Once timed out the current mode is automatically 
      canceled and the buzzer timer will switch to the Buzz mode. The buzzer 
      timer stays in the Buzz mode until it is canceled by pressing any of 
      the other three switches.
   5. The time period of the timer is activated by the press of the switch and 
      the time of the release is irrelevant as long as the button is released 
      before the timer times out. The following is not expected to happen, but 
      if the time switch is still pressed at the end of the timed period the 
      timer will switch to the buzz mode momentarily then jump back to the timer 
      mode starting a new time cycle. The modes would change too quickly in this 
      case for the buzzer sound to be audible (in the order of 10s of microseconds).


*/

#include "config_bits.h"  // device specific configuration
#include "pins.h"
#include "osc.h"
#include <timers.h>

struct sixteenbit_struct {          // this sets up a bitfield structure
    unsigned  lower:8;
    unsigned  upper:8;
};
union sixteenbit_parts {             // The union allows one to refer to the 
    struct sixteenbit_struct byte;   // same address space with different names.
    unsigned int whole_int;          // In this case one can make expressions with
};                                   // ether the whole_int (16 bits) or either byte
                                     // of the int (upper or lower 8 bits)
union sixteenbit_parts next_compare1;

void open_timer(void);
void open_compare(void);
void buzzer_task(void);
void read_process_switches(void);
void setup_state(void);
void time_is_up(void);
void ten_msec_task(void);
void reset_times(void);

enum state_type { Reset, TenSec, FiveSec, Buzz };
enum state_type state=Reset;

unsigned int time, ten_msec_count=0, sec_count=0;
const unsigned int ten_msec_duration = 10000u;

void main(void)
{

    set_osc_32MHz();   // sets osc speed to 32 MHz

    SPEAKER_DIR = INPUT;  // Set as an input until buzzer is to sound
    TEN_SEC_DIR = INPUT;  // refers to input pin
    FIVE_SEC_DIR = INPUT; // refers to input pin
    RESET_DIR = INPUT;    // refers to input pin
    BUZZ_NOW = INPUT;     // refers to input pin
    
    open_timer();         // these functions setup the hardware in
    open_compare();       //   the microcontroller


    while(1)              // this is the event loop which polls the switches,
    {                     // polls the event flags, and checks for time outs.
        read_process_switches(); 

        if ( (state == TenSec) && (sec_count == 10u)) time_is_up();
        else if ( (state == FiveSec) && (sec_count == 5u) ) time_is_up();
        if ( PIR2bits.CCP2IF  ) buzzer_task();
        if (PIR1bits.CCP1IF) ten_msec_task();
    }
}

void read_process_switches(void)
{
/* called by main() from within the event loop

The state is set to a value that corresponds to the switch that is pressed.
If no switch is pressed the state will not be changed.
If new state is the same as the old state nothing happens. If the new state is not
the same as the old state another function is called setup_state()
*/ 
    static enum state_type old_state=0;

    old_state = state;
                                //in order of priority
    if (RESET)  state = Reset;  // checks RESET switch INPUT
    else if (FIVE_SEC) state = FiveSec; // checks FIVE_SEC switch input
    else if (TEN_SEC) state = TenSec;   // checks TEN_SEC switch input
    else if (BUZZ_NOW) state = Buzz;    // checks BUZZ_NOW switch input
    if (state != old_state) 
    {
        time = ReadTimer1();   // read timer if there is a change in state
        setup_state();
    }
}

void setup_state()
{
/* called by read_process_switches() only when state has changed.
   Sets up the new state
*/
   
    switch (state) 
    {
        case Buzz:
            SPEAKER_DIR = OUTPUT;  // set control pin as an output
            break;
        case Reset:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            break;
        case TenSec:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            reset_times();
            break;
        case FiveSec:
            SPEAKER_DIR = INPUT;  // set control pin as high impedance
            reset_times();
            break;
    }
}

void reset_times(void)
{
/* called by setup_state()
   Sets the compare register to a time ten ms greater than the time read by
   read_process_switches. Also resets software counters and event flag
*/
            next_compare1.whole_int = time + ten_msec_duration;
            CCPR1H = next_compare1.byte.upper;
            CCPR1L = next_compare1.byte.lower;
            PIR1bits.CCP1IF = 0;
            ten_msec_count = 0;
            sec_count = 0;
}


void ten_msec_task(void)
{
/* called by main() from within event loop()

ten_msec_task() sets the new CCP1 compare time to the sum of  the timer1 count from the last
CCP1 flag event and a time interval of 10 ms. Thie new CCP1 compare time is put in the CCP1 compare 
registers. The CCP1 event flag is cleared.
Software counters are maintained to keep track of the number of ten ms intervals and the number of 
one second intervals that have passed.
*/
    next_compare1.whole_int = next_compare1.whole_int + ten_msec_duration;
    CCPR1H = next_compare1.byte.upper;
    CCPR1L = next_compare1.byte.lower;
    PIR1bits.CCP1IF = 0;
    ten_msec_count++;
    if (ten_msec_count >= 100u)
    {
        ten_msec_count = 0;
        sec_count++;
    }
}

void time_is_up(void)
{
/* Called by main() from within event loop
   Once the timer has timed out the state must be changed to Buzz
*/
    state = Buzz;            // timer over so jump to Buzz state
    SPEAKER_DIR = OUTPUT;    // enable buzzer output
    PIR1bits.CCP1IF = 0;     // reset timer1 interupt flag
}

void buzzer_task(void)
{
// called by main() from within the event loop
// sets up the time until the next buzzer event and toggles the output
// bit.
// Note that the output will actually make sound only if the SPEAKER pin is set to be an output.
// The condition of the output pin (output or high impedence) is controlled in setup_state().
// Buzzer task sets and clears the #1 output bit of the register regardless of if it is currently 
// controlling the speaker pin.

    enum SEQUENCE_ENUM { stepOne, stepTwo, stepThree, stepFour};

 
    static union sixteenbit_parts compare2_register = 0;
    // the variable compare_register contains the value that the compare register was last set to
    // then the value it will next be set to.

    static enum SEQUENCE_ENUM wave_seq = stepOne;
    static unsigned int duration[] = {270,350,350,2250}; // numbers in microseconds

    compare2_register.whole_int = compare2_register.whole_int + duration[wave_seq];
    CCPR2H = compare2_register.byte.upper;
    CCPR2L = compare2_register.byte.lower;
    
    PIR2bits.CCP2IF = 0;
    if ( (wave_seq == stepOne) || (wave_seq == stepThree) ) SPEAKER = HIGH;
    else SPEAKER = LOW;
    if (wave_seq == stepFour) wave_seq = stepOne;
    else wave_seq++;

}

void open_timer(void)
{
// called by main()  before event loop

    OpenTimer1( TIMER_INT_OFF & T1_16BIT_RW &
                T1_SOURCE_INT & T1_PS_1_8   &
                T1_OSC1EN_OFF & T1_SYNC_EXT_OFF &
                T1_SOURCE_CCP );
}

void open_compare(void)
{
// called by main() before event loop

    const unsigned char compare_mode_code = 0B00001010; // code from PIC18F4525 databook
                                                      // page 139 for CCPxCON register

    RCONbits.IPEN = 1;    // set to known state although hardware interups not used here
    INTCONbits.GIEH = 0;  // disable all interupts
    INTCONbits.GIEL = 0;
    PIE1bits.CCP1IE = 0;  // disable ccp1 interupt
    PIE2bits.CCP2IE = 0;  // disable ccp2 interupt
    
    CCP1CON = compare_mode_code; // use CPP1IF interupt flag and not the CCP1 pin
    CCP2CON = compare_mode_code; // use CPP2IF interupt flag and not the CCP2 pin
    CCPR2H = 0;
    CCPR2L = 0;
    next_compare1.whole_int = ReadTimer1() + ten_msec_duration;
    CCPR1H = next_compare1.byte.upper;
    CCPR1L = next_compare1.byte.lower;
    PIR1bits.CCP1IF = 0;
    PIR2bits.CCP2IF = 0;
    PIR1bits.CCP1IF = 0;
}

